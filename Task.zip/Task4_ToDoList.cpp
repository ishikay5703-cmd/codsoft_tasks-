/*
    CODSOFT C++ PROGRAMMING INTERNSHIP
    TASK 4 - TO-DO LIST
    -------------------------------------------------------
    A simple console-based to-do list manager that allows
    users to add, view, and delete tasks.

    Features implemented (as per task requirements):
    - Task Input:              Add tasks to the list
    - Add Task:                Function to add tasks
    - View Tasks:              Display list with status
                                (completed / pending)
    - Mark Task as Completed:  Mark tasks as completed
    - Remove Task:             Remove tasks from the list
    - Data persists for the duration of the session using
      a dynamic vector of Task objects (menu-driven)
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;

struct Task
{
    string description;
    bool isCompleted;
};

vector<Task> taskList;

// Adds a new task to the list
void addTask()
{
    cin.ignore(1000, '\n'); // clear leftover newline from previous input
    cout << "Enter the task description: ";
    string description;
    getline(cin, description);

    if (description.empty())
    {
        cout << "Task description cannot be empty. Task not added.\n";
        return;
    }

    Task newTask;
    newTask.description = description;
    newTask.isCompleted = false;
    taskList.push_back(newTask);

    cout << "Task added successfully!\n";
}

// Displays the list of tasks with their status
void viewTasks()
{
    if (taskList.empty())
    {
        cout << "\nYour to-do list is empty.\n";
        return;
    }

    cout << "\n--------------- YOUR TO-DO LIST ---------------\n";
    for (size_t i = 0; i < taskList.size(); i++)
    {
        cout << (i + 1) << ". [" << (taskList[i].isCompleted ? "Completed" : "Pending  ")
             << "] " << taskList[i].description << "\n";
    }
    cout << "-------------------------------------------------\n";
}

// Marks a chosen task as completed
void markTaskCompleted()
{
    viewTasks();
    if (taskList.empty()) return;

    cout << "Enter the task number to mark as completed: ";
    int taskNumber;
    while (!(cin >> taskNumber))
    {
        cout << "Invalid input. Enter a valid task number: ";
        cin.clear();
        cin.ignore(1000, '\n');
    }

    if (taskNumber < 1 || taskNumber > static_cast<int>(taskList.size()))
    {
        cout << "Invalid task number.\n";
        return;
    }

    taskList[taskNumber - 1].isCompleted = true;
    cout << "Task marked as completed!\n";
}

// Removes a chosen task from the list
void removeTask()
{
    viewTasks();
    if (taskList.empty()) return;

    cout << "Enter the task number to remove: ";
    int taskNumber;
    while (!(cin >> taskNumber))
    {
        cout << "Invalid input. Enter a valid task number: ";
        cin.clear();
        cin.ignore(1000, '\n');
    }

    if (taskNumber < 1 || taskNumber > static_cast<int>(taskList.size()))
    {
        cout << "Invalid task number.\n";
        return;
    }

    taskList.erase(taskList.begin() + (taskNumber - 1));
    cout << "Task removed successfully!\n";
}

// Displays the main menu
void displayMenu()
{
    cout << "\n================= TO-DO LIST MENU =================\n";
    cout << "1. Add Task\n";
    cout << "2. View Tasks\n";
    cout << "3. Mark Task as Completed\n";
    cout << "4. Remove Task\n";
    cout << "5. Exit\n";
    cout << "=====================================================\n";
    cout << "Enter your choice (1-5): ";
}

int main()
{
    cout << "###############################################\n";
    cout << "#                 TO-DO LIST                   #\n";
    cout << "#      (CodSoft C++ Internship - Task 4)       #\n";
    cout << "###############################################\n";

    int choice;
    bool running = true;

    while (running)
    {
        displayMenu();
        while (!(cin >> choice))
        {
            cout << "Invalid input. Enter a number between 1-5: ";
            cin.clear();
            cin.ignore(1000, '\n');
        }

        switch (choice)
        {
            case 1: addTask(); break;
            case 2: viewTasks(); break;
            case 3: markTaskCompleted(); break;
            case 4: removeTask(); break;
            case 5:
                cout << "\nExiting To-Do List. Goodbye!\n";
                running = false;
                break;
            default:
                cout << "Invalid choice. Please select between 1-5.\n";
        }
    }

    return 0;
}
