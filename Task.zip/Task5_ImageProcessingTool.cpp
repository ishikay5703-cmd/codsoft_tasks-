/*
    CODSOFT C++ PROGRAMMING INTERNSHIP
    TASK 5 - IMAGE PROCESSING TOOL
    -------------------------------------------------------
    Build a tool that allows users to perform various image
    processing operations like resizing, cropping, and
    filtering.

    Features implemented (as per task requirements):
    - Load Image:        Load a 24-bit uncompressed BMP image
    - Display Image:     Print image info (dimensions/preview)
    - Image Filters:     Grayscale, Blur, Sharpen
    - Color Adjustment:  Brightness and Contrast
    - Crop and Resize:   Crop a region / resize the image
    - Image Saving:      Save the processed image back to BMP
    - User Interface:    Simple menu-driven console interface

    NOTE ON DESIGN:
    This tool works directly with the 24-bit uncompressed BMP
    file format so that it has ZERO external library
    dependencies (no OpenCV / stb_image needed) and compiles
    with a plain C++ compiler anywhere. You can create a
    24-bit BMP test image using MS Paint ("Save As" -> "24-bit
    Bitmap") or any online PNG-to-BMP converter.
*/

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cstdint>
#include <cmath>
#include <algorithm>
using namespace std;

// ---------------- BMP FILE STRUCTURES ----------------
#pragma pack(push, 1)
struct BMPFileHeader
{
    uint16_t fileType{0x4D42}; // "BM"
    uint32_t fileSize{0};
    uint16_t reserved1{0};
    uint16_t reserved2{0};
    uint32_t dataOffset{0};
};

struct BMPInfoHeader
{
    uint32_t headerSize{40};
    int32_t  width{0};
    int32_t  height{0};
    uint16_t planes{1};
    uint16_t bitsPerPixel{24};
    uint32_t compression{0};
    uint32_t imageSize{0};
    int32_t  xPixelsPerMeter{0};
    int32_t  yPixelsPerMeter{0};
    uint32_t colorsUsed{0};
    uint32_t colorsImportant{0};
};
#pragma pack(pop)

// ---------------- IMAGE CLASS ----------------
class Image
{
public:
    int width = 0;
    int height = 0;
    // Pixel data stored as B,G,R triples, row-major, top-to-bottom
    vector<unsigned char> pixels;

    bool loadBMP(const string &filename)
    {
        ifstream file(filename, ios::binary);
        if (!file)
        {
            cout << "Error: Could not open file '" << filename << "'.\n";
            return false;
        }

        BMPFileHeader fileHeader;
        BMPInfoHeader infoHeader;

        file.read(reinterpret_cast<char *>(&fileHeader), sizeof(fileHeader));
        file.read(reinterpret_cast<char *>(&infoHeader), sizeof(infoHeader));

        if (fileHeader.fileType != 0x4D42)
        {
            cout << "Error: Not a valid BMP file.\n";
            return false;
        }
        if (infoHeader.bitsPerPixel != 24)
        {
            cout << "Error: Only 24-bit uncompressed BMP files are supported.\n";
            return false;
        }

        width = infoHeader.width;
        height = infoHeader.height;

        int rowPadded = (width * 3 + 3) & (~3);
        pixels.assign(static_cast<size_t>(width) * height * 3, 0);

        file.seekg(fileHeader.dataOffset, ios::beg);
        vector<unsigned char> rowBuffer(rowPadded);

        // BMP stores rows bottom-to-top; we store top-to-bottom internally
        for (int row = 0; row < height; row++)
        {
            file.read(reinterpret_cast<char *>(rowBuffer.data()), rowPadded);
            int destRow = height - 1 - row;
            for (int col = 0; col < width; col++)
            {
                size_t srcIdx = col * 3;
                size_t dstIdx = (static_cast<size_t>(destRow) * width + col) * 3;
                pixels[dstIdx + 0] = rowBuffer[srcIdx + 0]; // B
                pixels[dstIdx + 1] = rowBuffer[srcIdx + 1]; // G
                pixels[dstIdx + 2] = rowBuffer[srcIdx + 2]; // R
            }
        }

        file.close();
        return true;
    }

    bool saveBMP(const string &filename) const
    {
        if (pixels.empty())
        {
            cout << "Error: No image data to save.\n";
            return false;
        }

        int rowPadded = (width * 3 + 3) & (~3);
        int paddingBytes = rowPadded - width * 3;

        BMPFileHeader fileHeader;
        BMPInfoHeader infoHeader;

        infoHeader.width = width;
        infoHeader.height = height;
        infoHeader.imageSize = rowPadded * height;

        fileHeader.dataOffset = sizeof(BMPFileHeader) + sizeof(BMPInfoHeader);
        fileHeader.fileSize = fileHeader.dataOffset + infoHeader.imageSize;

        ofstream file(filename, ios::binary);
        if (!file)
        {
            cout << "Error: Could not create file '" << filename << "'.\n";
            return false;
        }

        file.write(reinterpret_cast<const char *>(&fileHeader), sizeof(fileHeader));
        file.write(reinterpret_cast<const char *>(&infoHeader), sizeof(infoHeader));

        unsigned char pad[3] = {0, 0, 0};

        for (int row = 0; row < height; row++)
        {
            int srcRow = height - 1 - row; // write bottom-to-top
            for (int col = 0; col < width; col++)
            {
                size_t idx = (static_cast<size_t>(srcRow) * width + col) * 3;
                file.write(reinterpret_cast<const char *>(&pixels[idx]), 3);
            }
            if (paddingBytes > 0)
                file.write(reinterpret_cast<const char *>(pad), paddingBytes);
        }

        file.close();
        return true;
    }

    unsigned char &at(int row, int col, int channel)
    {
        return pixels[(static_cast<size_t>(row) * width + col) * 3 + channel];
    }

    unsigned char at(int row, int col, int channel) const
    {
        return pixels[(static_cast<size_t>(row) * width + col) * 3 + channel];
    }
};

static unsigned char clampToByte(int value)
{
    return static_cast<unsigned char>(max(0, min(255, value)));
}

// ---------------- IMAGE FILTERS / OPERATIONS ----------------

// Converts the image to grayscale (equal B, G, R per pixel)
void applyGrayscale(Image &img)
{
    for (int row = 0; row < img.height; row++)
    {
        for (int col = 0; col < img.width; col++)
        {
            unsigned char b = img.at(row, col, 0);
            unsigned char g = img.at(row, col, 1);
            unsigned char r = img.at(row, col, 2);
            unsigned char gray = clampToByte(static_cast<int>(0.299 * r + 0.587 * g + 0.114 * b));
            img.at(row, col, 0) = gray;
            img.at(row, col, 1) = gray;
            img.at(row, col, 2) = gray;
        }
    }
    cout << "Grayscale filter applied.\n";
}

// Applies a simple 3x3 box blur
void applyBlur(Image &img)
{
    Image original = img;
    int kernelSize = 3;
    int offset = kernelSize / 2;

    for (int row = 0; row < img.height; row++)
    {
        for (int col = 0; col < img.width; col++)
        {
            int sums[3] = {0, 0, 0};
            int count = 0;

            for (int dy = -offset; dy <= offset; dy++)
            {
                for (int dx = -offset; dx <= offset; dx++)
                {
                    int nRow = row + dy;
                    int nCol = col + dx;
                    if (nRow >= 0 && nRow < img.height && nCol >= 0 && nCol < img.width)
                    {
                        for (int c = 0; c < 3; c++)
                            sums[c] += original.at(nRow, nCol, c);
                        count++;
                    }
                }
            }
            for (int c = 0; c < 3; c++)
                img.at(row, col, c) = clampToByte(sums[c] / count);
        }
    }
    cout << "Blur filter applied.\n";
}

// Applies a simple sharpening kernel
void applySharpen(Image &img)
{
    Image original = img;
    int kernel[3][3] = {
        { 0, -1,  0},
        {-1,  5, -1},
        { 0, -1,  0}
    };

    for (int row = 0; row < img.height; row++)
    {
        for (int col = 0; col < img.width; col++)
        {
            int sums[3] = {0, 0, 0};
            for (int dy = -1; dy <= 1; dy++)
            {
                for (int dx = -1; dx <= 1; dx++)
                {
                    int nRow = row + dy;
                    int nCol = col + dx;
                    if (nRow >= 0 && nRow < img.height && nCol >= 0 && nCol < img.width)
                    {
                        int weight = kernel[dy + 1][dx + 1];
                        for (int c = 0; c < 3; c++)
                            sums[c] += weight * original.at(nRow, nCol, c);
                    }
                }
            }
            for (int c = 0; c < 3; c++)
                img.at(row, col, c) = clampToByte(sums[c]);
        }
    }
    cout << "Sharpen filter applied.\n";
}

// Adjusts brightness by adding a constant offset to every channel
void adjustBrightness(Image &img, int offset)
{
    for (auto &p : img.pixels)
        p = clampToByte(static_cast<int>(p) + offset);
    cout << "Brightness adjusted by " << offset << ".\n";
}

// Adjusts contrast using the standard contrast factor formula
void adjustContrast(Image &img, double factor)
{
    for (auto &p : img.pixels)
    {
        double value = (static_cast<double>(p) - 128) * factor + 128;
        p = clampToByte(static_cast<int>(round(value)));
    }
    cout << "Contrast adjusted by factor " << factor << ".\n";
}

// Crops the image to the specified rectangle
bool cropImage(Image &img, int x, int y, int newWidth, int newHeight)
{
    if (x < 0 || y < 0 || newWidth <= 0 || newHeight <= 0 ||
        x + newWidth > img.width || y + newHeight > img.height)
    {
        cout << "Error: Invalid crop dimensions for this image.\n";
        return false;
    }

    vector<unsigned char> newPixels(static_cast<size_t>(newWidth) * newHeight * 3);

    for (int row = 0; row < newHeight; row++)
    {
        for (int col = 0; col < newWidth; col++)
        {
            for (int c = 0; c < 3; c++)
            {
                newPixels[(static_cast<size_t>(row) * newWidth + col) * 3 + c] =
                    img.at(row + y, col + x, c);
            }
        }
    }

    img.width = newWidth;
    img.height = newHeight;
    img.pixels = move(newPixels);
    cout << "Image cropped to " << newWidth << "x" << newHeight << ".\n";
    return true;
}

// Resizes the image using nearest-neighbor interpolation
void resizeImage(Image &img, int newWidth, int newHeight)
{
    vector<unsigned char> newPixels(static_cast<size_t>(newWidth) * newHeight * 3);

    double xRatio = static_cast<double>(img.width) / newWidth;
    double yRatio = static_cast<double>(img.height) / newHeight;

    for (int row = 0; row < newHeight; row++)
    {
        for (int col = 0; col < newWidth; col++)
        {
            int srcCol = min(img.width - 1, static_cast<int>(col * xRatio));
            int srcRow = min(img.height - 1, static_cast<int>(row * yRatio));
            for (int c = 0; c < 3; c++)
            {
                newPixels[(static_cast<size_t>(row) * newWidth + col) * 3 + c] =
                    img.at(srcRow, srcCol, c);
            }
        }
    }

    img.width = newWidth;
    img.height = newHeight;
    img.pixels = move(newPixels);
    cout << "Image resized to " << newWidth << "x" << newHeight << ".\n";
}

// Displays basic information about the image (console cannot show real
// graphics, so we print dimensions and a small ASCII-art brightness preview)
void displayImage(const Image &img)
{
    if (img.pixels.empty())
    {
        cout << "No image loaded.\n";
        return;
    }

    cout << "\nImage Info -> Width: " << img.width
         << " px, Height: " << img.height << " px\n";

    // Small ASCII preview (downsampled) so the user can visually confirm
    // the effect of filters directly in the console.
    const int previewCols = 60;
    const int previewRows = 30;
    const string shades = " .:-=+*#%@";

    cout << "\nASCII Preview:\n";
    for (int pr = 0; pr < previewRows; pr++)
    {
        for (int pc = 0; pc < previewCols; pc++)
        {
            int srcCol = pc * img.width / previewCols;
            int srcRow = pr * img.height / previewRows;
            srcCol = min(srcCol, img.width - 1);
            srcRow = min(srcRow, img.height - 1);

            unsigned char b = img.at(srcRow, srcCol, 0);
            unsigned char g = img.at(srcRow, srcCol, 1);
            unsigned char r = img.at(srcRow, srcCol, 2);
            int brightness = (r + g + b) / 3;
            int shadeIndex = brightness * (static_cast<int>(shades.size()) - 1) / 255;
            cout << shades[shadeIndex];
        }
        cout << "\n";
    }
}

// Displays the main menu
void displayMenu()
{
    cout << "\n================= IMAGE PROCESSING MENU =================\n";
    cout << "1. Load Image (24-bit BMP)\n";
    cout << "2. Display Image Info / Preview\n";
    cout << "3. Apply Grayscale Filter\n";
    cout << "4. Apply Blur Filter\n";
    cout << "5. Apply Sharpen Filter\n";
    cout << "6. Adjust Brightness\n";
    cout << "7. Adjust Contrast\n";
    cout << "8. Crop Image\n";
    cout << "9. Resize Image\n";
    cout << "10. Save Image\n";
    cout << "11. Exit\n";
    cout << "===========================================================\n";
    cout << "Enter your choice (1-11): ";
}

int main()
{
    cout << "###############################################\n";
    cout << "#            IMAGE PROCESSING TOOL             #\n";
    cout << "#      (CodSoft C++ Internship - Task 5)       #\n";
    cout << "###############################################\n";
    cout << "\nNOTE: This tool reads/writes 24-bit uncompressed BMP files.\n";

    Image image;
    bool imageLoaded = false;
    int choice;
    bool running = true;

    while (running)
    {
        displayMenu();
        while (!(cin >> choice))
        {
            cout << "Invalid input. Enter a number between 1-11: ";
            cin.clear();
            cin.ignore(1000, '\n');
        }

        switch (choice)
        {
            case 1:
            {
                cout << "Enter the BMP filename to load (e.g. input.bmp): ";
                string filename;
                cin >> filename;
                imageLoaded = image.loadBMP(filename);
                if (imageLoaded)
                    cout << "Image loaded successfully! (" << image.width
                         << "x" << image.height << ")\n";
                break;
            }
            case 2:
                if (imageLoaded) displayImage(image);
                else cout << "Please load an image first (option 1).\n";
                break;
            case 3:
                if (imageLoaded) applyGrayscale(image);
                else cout << "Please load an image first (option 1).\n";
                break;
            case 4:
                if (imageLoaded) applyBlur(image);
                else cout << "Please load an image first (option 1).\n";
                break;
            case 5:
                if (imageLoaded) applySharpen(image);
                else cout << "Please load an image first (option 1).\n";
                break;
            case 6:
                if (imageLoaded)
                {
                    cout << "Enter brightness offset (-255 to 255): ";
                    int offset;
                    cin >> offset;
                    adjustBrightness(image, offset);
                }
                else cout << "Please load an image first (option 1).\n";
                break;
            case 7:
                if (imageLoaded)
                {
                    cout << "Enter contrast factor (e.g. 1.0 = no change, >1 = more contrast): ";
                    double factor;
                    cin >> factor;
                    adjustContrast(image, factor);
                }
                else cout << "Please load an image first (option 1).\n";
                break;
            case 8:
                if (imageLoaded)
                {
                    int x, y, w, h;
                    cout << "Enter crop start X: "; cin >> x;
                    cout << "Enter crop start Y: "; cin >> y;
                    cout << "Enter crop width: ";   cin >> w;
                    cout << "Enter crop height: ";  cin >> h;
                    cropImage(image, x, y, w, h);
                }
                else cout << "Please load an image first (option 1).\n";
                break;
            case 9:
                if (imageLoaded)
                {
                    int w, h;
                    cout << "Enter new width: ";  cin >> w;
                    cout << "Enter new height: "; cin >> h;
                    if (w > 0 && h > 0) resizeImage(image, w, h);
                    else cout << "Error: Width and height must be positive.\n";
                }
                else cout << "Please load an image first (option 1).\n";
                break;
            case 10:
                if (imageLoaded)
                {
                    cout << "Enter filename to save as (e.g. output.bmp): ";
                    string outFilename;
                    cin >> outFilename;
                    if (image.saveBMP(outFilename))
                        cout << "Image saved successfully as '" << outFilename << "'.\n";
                }
                else cout << "Please load an image first (option 1).\n";
                break;
            case 11:
                cout << "\nExiting Image Processing Tool. Goodbye!\n";
                running = false;
                break;
            default:
                cout << "Invalid choice. Please select between 1-11.\n";
        }
    }

    return 0;
}
